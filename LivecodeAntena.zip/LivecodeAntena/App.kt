package main.livecodeAntena

import main.livecodeAntena.Operation.getCoordinate
import main.livecodeAntena.entryInfo.inputNumberOfAntenna


fun main() {
    val totalInputAntenna = inputNumberOfAntenna()
    getCoordinate(totalInputAntenna)
}
