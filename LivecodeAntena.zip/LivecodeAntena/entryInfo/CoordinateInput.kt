package main.livecodeAntena.entryInfo

fun inputCoordinatePosition(): Array<Int?>{
    print("Input Coordinate Point x: ")
    val absis = readLine()?.toInt()
    print("Input Coordinate Point y: ")
    val ordinat = readLine()?.toInt()
    println("Coordinate Point ($absis, $ordinat)")
    return arrayOf(absis, ordinat)
}