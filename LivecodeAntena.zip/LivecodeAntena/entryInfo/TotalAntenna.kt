package main.livecodeAntena.entryInfo

fun inputNumberOfAntenna(): Int?{
    print(">Input Total Antenna That You Have: ")
    return readLine()?.toInt()
}