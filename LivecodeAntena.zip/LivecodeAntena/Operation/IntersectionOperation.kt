package main.livecodeAntena.Operation

import main.livecodeAntena.myCoordinate.Coordinate


fun getIntersectionAntenna(totalInputAntenna: Int?, antenna: MutableList<MutableSet<Coordinate>>) {

    if (totalInputAntenna == 1) {
        println("Didn't have intersection because antenna only one")
    } else if (totalInputAntenna == 2) {
        val intersectionAntenna = antenna[0].intersect(antenna[1])
        println("You have intersection set like = $intersectionAntenna")
    } else if (totalInputAntenna == 3) {
        var intersectionList: MutableList<MutableSet<main.livecodeAntena.myCoordinate.Coordinate>> = mutableListOf()
        for (x in 0 until totalInputAntenna) {
            for (y in x + 1 until totalInputAntenna) {
                val intersectionOfAntenna = antenna[x].intersect(antenna[y]).toMutableSet()
                intersectionList.add(intersectionOfAntenna)
            }
        }
        var join: Set<main.livecodeAntena.myCoordinate.Coordinate> = mutableSetOf()
        for (i in intersectionList.indices) {
            join = join + intersectionList[i].union(intersectionList[(i+1)%intersectionList.size])
        }
        println("Area covered more than one Anthena ${join.toString()}")
        println("Output ${join.toString()}")
    }
}