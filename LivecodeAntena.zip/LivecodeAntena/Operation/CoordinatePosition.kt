package main.livecodeAntena.Operation

import main.livecodeAntena.entryInfo.inputCoordinatePosition
import main.livecodeAntena.myCoordinate.Coordinate


fun getCoordinate(totalInputAntenna: Int?){
    var antennaList = mutableListOf<MutableSet<Coordinate>>()
    if (totalInputAntenna == 3) {
        for (sequences in 1..totalInputAntenna!!) {
            println("Antenna $sequences")
            val antenna = inputCoordinatePosition()
            val antennaCoordinate = coordinateAntenna(antenna)
            antennaList.add(antennaCoordinate)
            println("Set $sequences = $antennaCoordinate")
        }
        getIntersectionAntenna(totalInputAntenna, antennaList)
    } else if (totalInputAntenna == 2) {
        for (sequences in 1..totalInputAntenna!!) {
            println("Antenna $sequences")
            val antenna = inputCoordinatePosition()
            val antennaCoordinate = coordinateAntenna(antenna)
            antennaList.add(antennaCoordinate)
            println("Set $sequences = $antennaCoordinate")
        }
        getIntersectionAntenna(totalInputAntenna, antennaList)
    }

    else {
        println("Sorry, Your Antenna only one. So its doesn't has intersection")
    }
}
fun coordinateAntenna(antenna: Array<Int?>): MutableSet<Coordinate> {
    val coordinate = mutableSetOf<Coordinate>()
    val lowerboundOfAbsis = antenna[0]?.minus(1)
    val upperboundOfAbsis = antenna[0]?.plus(1)
    val lowerboundOfOrdinate = antenna[1]?.minus(1)
    val upperboundOfOrdinate = antenna[1]?.plus(1)
    for (x in lowerboundOfAbsis!!..upperboundOfAbsis!!) {
        for (y in lowerboundOfOrdinate!!..upperboundOfOrdinate!!) {
            coordinate.add(Coordinate(x, y))
        }
    }
    return coordinate
}
